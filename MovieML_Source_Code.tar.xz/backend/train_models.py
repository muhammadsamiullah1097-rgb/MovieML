from app.services.training import run_model


models = [
    ("classification", "rating_tier", "random_forest"),
    ("regression", "vote_average", "random_forest_regression"),
    ("text", "primary_genre", "tfidf_naive_bayes"),
]


for task, target, model in models:
    print(f"Training {task}: {model}")
    result = run_model(None, task, target, model)
    print(f"{result['model_name']} completed")
    print(f"Metrics: {result['metrics']}")
    print(f"Saved: {result['saved_model']}")
    print("-" * 40)

print("All reference models are ready.")
