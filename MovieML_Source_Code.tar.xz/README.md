# MovieML Studio

A student-level Machine Learning project based on **The Movies Dataset** from Kaggle. It includes a FastAPI backend, a website, model selection, model comparison, preprocessing, feature analysis, and movie recommendations.

## Dataset

Kaggle: https://www.kaggle.com/datasets/rounakbanik/the-movies-dataset

The project includes these CSV files in `backend/data/raw/`:

- `movies_metadata.csv`
- `ratings_small.csv`
- `keywords.csv`
- `links_small.csv`

## ML Modules

### Classification — 12 models

Predicts a movie rating group (Low, Medium, or High) using the movie information.

### Regression — 8 models

Predicts the movie's `vote_average` rating.

### Text Classification — 2 models

Predicts the movie's main genre using its title and overview.

### Preprocessing and Feature Analysis

Includes missing-value handling, duplicate checking, encoding, scaling, SMOTE, RFE, and PCA.

### Movie Recommendations

Includes content-based recommendations and collaborative filtering using MovieLens ratings.

## How to Run

**Run all commands from the `backend` folder.** Open the project in VS Code, open the terminal, and enter:

### 1. Open the backend folder

```bash
cd backend
```

### 2. Install the libraries

```bash
pip install -r requirements.txt
```

### 3. Train the reference models (only if model files are missing)

The ZIP already includes three trained model files in `backend/artifacts/`, so you can skip this step for the first run.

To train them again or recreate missing model files, run:

```bash
python train_models.py
```

### 4. Start the backend

```bash
uvicorn app.main:app --reload
```

### 5. Open the website

Open this address in your browser:

**http://127.0.0.1:8000**

The MovieML website will load. Select a task, choose a model, set the available options, and click Run Model. Use Compare All to compare the algorithms for the selected task.

API documentation is available at:

**http://127.0.0.1:8000/docs**

## Stop the Project

Press `Ctrl + C` in the terminal where Uvicorn is running.

## Project Structure

```text
MovieML_Midterm_Project/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   ├── evaluation/
│   │   ├── models/
│   │   │   ├── classification/
│   │   │   ├── regression/
│   │   │   └── text/
│   │   ├── preprocessing/
│   │   ├── services/
│   │   └── utils/
│   ├── artifacts/
│   ├── data/
│   │   ├── raw/
│   │   ├── derived/
│   │   └── uploads/
│   ├── requirements.txt
│   └── train_models.py
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── docs/
├── tests/
└── README.md
```

## Main API Routes

| Route | Purpose |
|---|---|
| `GET /api/health` | Check API status |
| `GET /api/datasets` | Dataset details |
| `GET /api/summary` | CSV record counts |
| `GET /api/models` | List available models |
| `POST /api/run` | Run one selected model |
| `POST /api/compare` | Compare models for a task |
| `GET /api/preprocessing` | Data quality report |
| `GET /api/features` | RFE and PCA report |
| `POST /api/recommend/content` | Content-based recommendations |
| `POST /api/recommend/collaborative` | Collaborative recommendations |

## Notes

- The model files in `backend/artifacts/` were trained with scikit-learn 1.8.0.
- Model evaluation uses a held-out test split. Results are not guaranteed to be perfect.
- Classification groups are created from TMDB `vote_average`; this is not a personal rating prediction.
- Collaborative recommendations use the users and ratings available in `ratings_small.csv`.
- Detailed dataset notes and sample evaluation results are available in the `docs/` folder.
