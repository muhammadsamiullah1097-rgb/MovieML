# Dataset setup

Download **The Movies Dataset** from Kaggle:
https://www.kaggle.com/datasets/rounakbanik/the-movies-dataset

Extract these four files into `backend/data/raw/`:

- `movies_metadata.csv`
- `ratings_small.csv`
- `keywords.csv`
- `links_small.csv`

The project can create the trained model files by running `python train_models.py` from the `backend` folder after installing `requirements.txt`.
